data:extend(
{
  {
    type = "item",
    name = "car2",
    icon = "__MAIN-DyTech-Machine__/graphics/cars/car2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a-c",
    place_result = "car2",
    stack_size = 10
  },
}
)