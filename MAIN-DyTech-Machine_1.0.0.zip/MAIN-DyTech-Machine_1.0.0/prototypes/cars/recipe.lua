data:extend(
{ 
  {
    type = "recipe",
    name = "car2",
    enabled = false,
    ingredients =
    {
      {"car", 1},
      {"lead-plate", 75},
      {"advanced-processing-unit", 2},
      {"tungsten-gear-wheel", 12},
    },
    result = "car2"
  },
}
)