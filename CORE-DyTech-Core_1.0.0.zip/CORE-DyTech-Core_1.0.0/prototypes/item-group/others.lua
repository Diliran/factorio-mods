data:extend(
{
  {
    type = "item-subgroup",
    name = "defensive-walls",
    group = "combat",
    order = "w"
  },
}
)