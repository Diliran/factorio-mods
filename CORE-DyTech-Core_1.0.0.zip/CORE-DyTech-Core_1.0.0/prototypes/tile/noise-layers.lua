data:extend(
{
  {
    type = "noise-layer",
    name = "sand"
  },
  {
    type = "noise-layer",
    name = "random"
  },
  {
    type = "noise-layer",
    name = "metallurgy-ores"
  },
  {
    type = "noise-layer",
    name = "gems"
  },
  {
    type = "noise-layer",
    name = "lava"
  },
  {
    type = "noise-layer",
    name = "liquid-metals"
  },
  {
    type = "noise-layer",
    name = "gold-ore"
  },
  {
    type = "noise-layer",
    name = "zinc-ore"
  },
  {
    type = "noise-layer",
    name = "tungsten-ore"
  },
  {
    type = "noise-layer",
    name = "lead-ore"
  },
  {
    type = "noise-layer",
    name = "silver-ore"
  },
  {
    type = "noise-layer",
    name = "tin-ore"
  },
  {
    type = "noise-layer",
    name = "cobalt-ore"
  },
  {
    type = "noise-layer",
    name = "ardite-ore"
  },
}
)