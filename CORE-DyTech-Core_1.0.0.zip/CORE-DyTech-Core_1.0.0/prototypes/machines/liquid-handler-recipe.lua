data:extend(
{
  {
    type = "recipe",
    name = "liquid-handler",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {"rotor-1", 10},
      {"electronic-circuit", 3},
      {"pipe", 2},
      {"frame-1", 1},
    },
    result= "liquid-handler"
  },
}
)
