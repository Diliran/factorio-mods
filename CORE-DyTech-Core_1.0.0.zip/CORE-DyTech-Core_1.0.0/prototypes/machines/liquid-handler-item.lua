data:extend(
{
  {
    type = "item",
    name = "liquid-handler",
    icon = "__CORE-DyTech-Core__/graphics/machines/liquid-handler.png",
    flags = {"goes-to-quickbar"},
    subgroup = "assembling",
    order = "liquid-handler",
    place_result = "liquid-handler",
    stack_size = 50
  },
}
)
