data:extend(
{
  {
    type = "autoplace-control",
    name = "magma",
    richness = true,
    order = "m"
  },
  {
    type = "autoplace-control",
    name = "metallurgy-ores",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "gemstones",
    richness = true,
    order = "g-s"
  },
}
)
