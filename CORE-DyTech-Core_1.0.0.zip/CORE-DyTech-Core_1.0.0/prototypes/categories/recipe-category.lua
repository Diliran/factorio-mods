data:extend(
{
  {
    type = "recipe-category",
    name = "crafting"
  },
  {
    type = "recipe-category",
    name = "smelting"
  },
  {
    type = "recipe-category",
    name = "packing"
  },
  {
    type = "recipe-category",
    name = "unpacking"
  },
  {
    type = "recipe-category",
    name = "gem-crushing"
  },
  {
    type = "recipe-category",
    name = "gem-grinding"
  },
  {
    type = "recipe-category",
    name = "compressing"
  },
  {
    type = "recipe-category",
    name = "gem-polishing"
  },
  {
    type = "recipe-category",
    name = "converter"
  },
  {
    type = "recipe-category",
    name = "recycling"
  },
  {
    type = "recipe-category",
    name = "metallurgy-gear"
  },
  {
    type = "recipe-category",
    name = "metallurgy-wire"
  },
  {
    type = "recipe-category",
    name = "metallurgy-circuit"
  },
  {
    type = "recipe-category",
    name = "metallurgy-ammo-basic"
  },
  {
    type = "recipe-category",
    name = "metallurgy-ammo-advanced"
  },
  {
    type = "recipe-category",
    name = "metallurgy-tool"
  },
  {
    type = "recipe-category",
    name = "lava"
  },
  {
    type = "recipe-category",
    name = "air-collection"
  },
  {
    type = "recipe-category",
    name = "centrifuge"
  },
  {
    type = "recipe-category",
    name = "forge"
  },
  {
    type = "recipe-category",
    name = "blast-furnace"
  },
  {
    type = "recipe-category",
    name = "liquid-handler"
  },
  {
    type = "recipe-category",
    name = "lava-heater"
  },
  {
    type = "recipe-category",
    name = "lava-cooler"
  },
}
)
