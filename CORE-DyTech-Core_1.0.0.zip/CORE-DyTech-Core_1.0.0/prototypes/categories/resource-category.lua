data:extend(
{
  {
    type = "resource-category",
    name = "basic-solid"
  },
  {
    type = "resource-category",
    name = "basic-fluid"
  },
  {
    type = "resource-category",
    name = "gemstones"
  },
  {
    type = "resource-category",
    name = "lava-magma"
  },
}
)
