data:extend(
{ 
  {
    type = "recipe",
    name = "rubber-seed",
    energy_required = 1,
    ingredients = 
	{
	  {"resin", 1}
	},
    result = "rubber-seed"
  },
}
)