data:extend(
{
  {
    type = "item",
    name = "rubber-seed",
    icon = "__CORE-DyTech-Core__/graphics/rubber-tree/icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "rubber-seed",
    place_result = "rubber-seed",
    fuel_value = "1MJ",
    stack_size = 50
  },
}
)