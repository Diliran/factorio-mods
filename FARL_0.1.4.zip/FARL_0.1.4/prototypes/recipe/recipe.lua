data:extend(
  {
    {
      type = "recipe",
      name = "farl",
      enabled = "false",
      ingredients =
      {
        {"diesel-locomotive", 1},
        {"long-handed-inserter", 2},
        {"steel-plate", 5},
      },
      result = "farl"
    }
  })
