require("prototypes.recipe.peaceful-mode")
require("prototypes.technology.peaceful-mode")