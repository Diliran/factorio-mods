data:extend(
{
	{
		type = "recipe",
		name = "alien-artifact",
		enabled = "false",
		category = "chemistry",
		energy_required = 5,
		ingredients = {
			{type="fluid", name="crude-oil", amount=20},
			{type="fluid", name="sulfuric-acid", amount=20},
		},
		result = "alien-artifact"
	}
})