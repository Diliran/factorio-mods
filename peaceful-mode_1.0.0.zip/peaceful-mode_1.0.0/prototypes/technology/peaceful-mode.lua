data:extend(
{
  {
    type = "technology",
    name = "alien-artifact",
    icon = "__base__/graphics/icons/alien-artifact.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "alien-artifact"
      }
    },
    unit =
    {
      count = 200,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
      },
      time = 10
    },
    order = "e-f-a"
  },
})